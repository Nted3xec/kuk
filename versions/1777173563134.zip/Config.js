const fs = require('fs')

global.Token  = "8367220367:AAHkFXHWWBvxKZkMCAiVKBxtwlxi0VN5kfA";
global.Owner  = "8529380482";
global.prefix = ".";
global.Version = "1.0.0";
global.timeoutMs = 10000;
global.antiLink = false;
global.antiToxic = false;

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
